# PF1e Monster Creation Rules

Install this module by pasting this link: https://raw.githubusercontent.com/Vazre/PF1e-Monster-Creation-Rules/main/module.json

into the install module dialog on the Foundry Add-on Module tab.

Once you enable this module, it adds one compendium with the monster creation template classes from Bestiary 1, which I sourced from
https://www.d20pfsrd.com/bestiary/rules-for-monsters/monster-creation/

